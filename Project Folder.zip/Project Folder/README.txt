Step 1: Initiate the local web server. It can posssible by accessing the python program located in current repository which is manage.py

Step 2: Then use URL to access it. 

Step 3: After that run the local web browser by utilizingh that URL or it should be achived through IP address.

Step 4: Determine line of HelloWorl function activation then run running.py file. 

